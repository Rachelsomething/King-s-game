from graphics import *
from random import *
from Setting import *


class Question:
    """ question """
    def __init__(self, window, center, color,PATH_TO_IMAGES_FOLDER):
        self.PATH_TO_IMAGES_FOLDER = PATH_TO_IMAGES_FOLDER
        self.color = color
        self.window = window
        liste = [0,1,2,3,4,5]
        listp = [0,1,2,3,4,5,6,7]
        self.liste = liste.copy()
        self.listp = listp.copy()
        e = randint(0,5)
        p = randint(0,7)
        self.X = center.getX()
        self.Y = center.getY()
        self.word = ''
        self.a = Text(Point(self.X, self.Y - 72), self.word)
        self.b = Text(Point(self.X, self.Y - 24 ), self.word)
        self.c = Text(Point(self.X, self.Y + 24 ), self.word)
        self.d = Text(Point(self.X, self.Y + 72 ), self.word)
        self.a.setSize(25)
        self.b.setSize(25)
        self.c.setSize(25)
        self.d.setSize(25)
        self.a.setTextColor(color)
        self.b.setTextColor(color)
        self.c.setTextColor(color)
        self.d.setTextColor(color)


    def qandA(self, status):
        eq = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/Economyquestions.txt","r")
        er = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/Economyreaction.txt","r")
        pq = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/Popularityquestion.txt","r")
        pr = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/Popularityreaction.txt","r")
        if status == 'eq':
            a = []
            for line in eq:
                sline = line.split("@")
                a.append(sline)
            return a
        elif status == 'er':
            a = []
            for line in er:
                sline = line.split("@")
                a.append(sline)
            return a
        elif status == 'pq':
            a = []
            for line in pq:
                sline = line.split("@")
                a.append(sline)
            return a
        elif status == 'pr':
            a = []
            for line in pr:
                sline = line.split("@")
                a.append(sline)
            return a
        eq.close()
        er.close()
        pq.close()
        pr.close()

    def questionep(self,status):
        if status == "e":
            questions = self.qandA('eq')
            reactions = self.qandA('er')
            num = randint(0,5)
            while self.liste[num] == "-":
                num = randint(0,5)
            self.liste[num] = "-"
            self.questionPrint(questions[num])
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                r = self.reactionPrint('A',reactions[num*2])
                return r
            elif k == 'b':
                r = self.reactionPrint('B',reactions[num*2+1])
                return r
        elif status == "p":
            questions = self.qandA('pq')
            reactions = self.qandA('pr')
            num = randint(0,7)
            while self.listp[num] == "-":
                num = randint(0,7)
            self.listp[num] = "-"
            self.questionPrint(questions[num])
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                r = self.reactionPrint('A',reactions[num*2])
                return r
            elif k == 'b':
                r = self.reactionPrint('B',reactions[num*2+1])
                return r
    def erase(self):
        self.a.undraw()
        self.b.undraw()
        self.c.undraw()
        self.d.undraw()

    def questionf(self):
        status = randint(1,2)
        if status == 1:
            questions = self.qandA('eq')
            reactions = self.qandA('er')
            num = randint(0,5)
            self.questionPrint(questions[num])
            k = ''
            t = 0
            self.d = Text(Point(self.X, self.Y + 72), "3")
            self.d.setSize(25)
            self.d.setTextColor('white')
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                t += 0.00005
                if 0.099 < t < 0.101:
                    self.d.undraw()
                    self.d = Text(Point(self.X, self.Y + 72), "2")
                    self.d.setSize(25)
                    self.d.setTextColor('white')
                    self.d.draw(self.window)
                if 0.199 < t < 0.201:
                    self.d.undraw()
                    self.d = Text(Point(self.X, self.Y + 72), "1")
                    self.d.setSize(25)
                    self.d.setTextColor('white')
                    self.d.draw(self.window)
                if 0.299 < t < 0.301:
                    break
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                r = reactions[num*2][-1]
                return eval(r)
            elif k == 'b':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                r = reactions[num*2+1][-1]
                return eval(r)
            elif k == '':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                return -20
        elif status == 2:
            questions = self.qandA('pq')
            reactions = self.qandA('pr')
            num = randint(0,7)
            self.questionPrint(questions[num])
            k = ''
            t = 0
            self.d = Text(Point(self.X, self.Y + 72), "3")
            self.d.setSize(25)
            self.d.setTextColor('white')
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                t += 0.00005
                if 0.099 < t < 0.101:
                    self.d.undraw()
                    self.d = Text(Point(self.X, self.Y + 72), "2")
                    self.d.setSize(25)
                    self.d.setTextColor('white')
                    self.d.draw(self.window)
                if 0.199 < t < 0.201:
                    self.d.undraw()
                    self.d = Text(Point(self.X, self.Y + 72), "1")
                    self.d.setSize(25)
                    self.d.setTextColor('white')
                    self.d.draw(self.window)
                if 0.299 < t < 0.301:
                    break
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                r = reactions[num*2][-1]
                return eval(r)
            elif k == 'b':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                r = reactions[num*2+1][-1]
                return eval(r)
            elif k == '':
                self.d.undraw()
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                return -20



    def questionPrint(self,linem):
        Y = self.Y - 120
        i = -len(linem)
        for a in range(0,4):
            Y += 48
            if a == 0:
                word = linem[i]
                self.a = Text(Point(self.X, Y), word)
                self.a.setSize(25)
                self.a.setTextColor(self.color)
                self.a.draw(self.window)
                i += 1
            elif a == 1:
                if i >= -2:
                    self.b = Text(Point(self.X, Y), self.word)
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.b = Text(Point(self.X, Y), word)
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    i += 1
            elif a == 2:
                if i >= -2:
                    self.c = Text(Point(self.X, Y), self.word)
                    self.c.setSize(25)
                    self.c.setTextColor(self.color)
                    self.c.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.c = Text(Point(self.X, Y), word)
                    self.c.setSize(25)
                    self.c.setTextColor(self.color)
                    self.c.draw(self.window)
                    i += 1
            elif a == 3:
                if i >= -2:
                    self.d = Text(Point(self.X, Y), self.word)
                    self.d.setSize(25)
                    self.d.setTextColor(self.color)
                    self.d.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.d = Text(Point(self.X, Y), word)
                    self.d.setSize(25)
                    self.d.setTextColor(self.color)
                    self.d.draw(self.window)
                    i += 1
        a = self.window.getKey()
        self.a.undraw()
        self.b.undraw()
        self.c.undraw()
        self.d.undraw()
        self.a = Text(Point(self.X, self.Y - 72), linem[-3])
        self.b = Text(Point(self.X, self.Y - 24 ), linem[-2])
        self.c = Text(Point(self.X, self.Y + 50 ), linem[-1])
        self.a.setSize(25)
        self.b.setSize(25)
        self.c.setSize(25)
        self.a.setTextColor(self.color)
        self.b.setTextColor(self.color)
        self.c.setTextColor(self.color)
        self.a.draw(self.window)
        self.b.draw(self.window)
        self.c.draw(self.window)

    def reactionPrint(self, status,linem):
        Y = self.Y - 120
        if status == 'A':
            self.twink(self.b,4)
        elif status == 'B':
            self.twink(self.c,4)
        self.a.undraw()
        self.b.undraw()
        self.c.undraw()
        i = -len(linem)
        for a in range(0,4):
            Y += 48
            if a == 0:
                word = linem[i]
                self.a = Text(Point(self.X, Y), word)
                self.a.setSize(25)
                self.a.setTextColor(self.color)
                self.a.draw(self.window)
                i += 1
            elif a == 1:
                if i >= -1:
                    self.b = Text(Point(self.X, Y), self.word)
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.b = Text(Point(self.X, Y), word)
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    i += 1
            elif a == 2:
                if i >= -1:
                    self.c = Text(Point(self.X, Y), self.word)
                    self.c.setSize(25)
                    self.c.setTextColor(self.color)
                    self.c.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.c = Text(Point(self.X, Y), word)
                    self.c.setSize(25)
                    self.c.setTextColor(self.color)
                    self.c.draw(self.window)
                    i += 1
            elif a == 3:
                if i >= -1:
                    self.d = Text(Point(self.X, Y), self.word)
                    self.d.setSize(25)
                    self.d.setTextColor(self.color)
                    self.d.draw(self.window)
                    i += 1
                else:
                    word = linem[i]
                    self.d = Text(Point(self.X, Y), word)
                    self.d.setSize(25)
                    self.d.setTextColor(self.color)
                    self.d.draw(self.window)
                    i += 1
        a = self.window.getKey()
        self.a.undraw()
        self.b.undraw()
        self.c.undraw()
        self.d.undraw()
        numm = linem[-1]
        return numm


    def twink(self,text,number):
        for i in range(0,number):
            text.undraw()
            text.setTextColor("blue")
            text.draw(self.window)
            time.sleep(0.2)
            text.undraw()
            text.setTextColor(self.color)
            text.draw(self.window)
            time.sleep(0.2)

    def decision(self):
        self.a = Text(Point(self.X, self.Y - 72), "Where you wanna go today?")
        self.b = Text(Point(self.X, self.Y - 24 ), "A. The town")
        self.c = Text(Point(self.X, self.Y + 50 ), "B. The forest")
        self.d = Text(Point(self.X, self.Y + 72 ), self.word)
        self.a.setSize(25)
        self.b.setSize(25)
        self.c.setSize(25)
        self.a.setTextColor(self.color)
        self.b.setTextColor(self.color)
        self.c.setTextColor(self.color)
        self.a.draw(self.window)
        self.b.draw(self.window)
        self.c.draw(self.window)
        self.d.draw(self.window)

        while True:
            k = self.window.checkKey()
            if k == 'a' or k == 'b':
                break
        if k == 'a':
            self.twink(self.b,4)
        elif k == 'b':
            self.twink(self.c,4)
        return k

    def morp(self,k):
        if k == 'a':
            self.a.undraw()
            self.b.undraw()
            self.c.undraw()
            self.a = Text(Point(self.X, self.Y - 72), "What do you wanna do?")
            self.b = Text(Point(self.X, self.Y - 24 ), "A. Raise money")
            self.c = Text(Point(self.X, self.Y + 50 ), "B. Raise reputation")
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor(self.color)
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            while True:
                p = self.window.checkKey()
                if p == 'a' or p == 'b':
                    break
            if p == 'a':
                self.twink(self.b,4)
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                return 'e'
            elif p == 'b':
                self.twink(self.c,4)
                self.a.undraw()
                self.b.undraw()
                self.c.undraw()
                return 'p'
        elif k == 'b':
            self.a.undraw()
            self.b.undraw()
            self.c.undraw()

    def introTorF(self,setting,k,number):
        if k == 'a':
            if number > 1:
                num = randint(1,2)
                if num == 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The town is cooler than last time.")
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
                else:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The town is warmer than last time.")
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
            elif number == 1:
                self.b = Text(Point(self.X, self.Y - 24 ), "The town is peaceful.")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
        elif k == 'b':
            if 50 <= setting.get("LUCK") <= 65:
                if number > 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "Peaceful.")
                    self.b.setSize(25)
                    self.b.setTextColor("red")
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
                elif number == 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The forest become much more deserted.")
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
            elif 75 <= setting.get("LUCK") <= 90:
                if number > 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "Peaceful. As you wish.")
                    self.b.setSize(25)
                    self.b.setTextColor("red")
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
                elif number == 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The forest is deeply silent.")
                    self.b.setSize(25)
                    self.b.setTextColor("red")
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
            elif number > 1:
                num = randint(1,2)
                if num == 1:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The forest is cooler than last time.")
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
                else:
                    self.b = Text(Point(self.X, self.Y - 24 ), "The forest is warmer than last time.")
                    self.b.setSize(25)
                    self.b.setTextColor(self.color)
                    self.b.draw(self.window)
                    a = self.window.getKey()
                    self.b.undraw()
            elif number == 1:
                self.b = Text(Point(self.X, self.Y - 24 ), "The forest is peaceful.")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()



    def intro(self,met,die,name):
        if name == 'eason':
            self.b = Text(Point(self.X, self.Y - 24), "You encounter another monster, he smells funny.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Eason: SSsup, can you hold these snakes for a second.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            if met > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Eason: I sssthink we have met before")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            if die > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Eason: And, you seem a little bit dangerousssss.")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
                self.b = Text(Point(self.X, self.Y - 24), "Eason: Whatever, can you hep me with thisssss?")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "You don't really like snakes.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.a = Text(Point(self.X, self.Y - 72), "Do you wanna help him?")
            self.b = Text(Point(self.X, self.Y - 24 ), "OK")
            self.c = Text(Point(self.X, self.Y + 50 ), "Kill him")
            self.d = Text(Point(self.X, self.Y + 72 ), self.word)
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor('red')
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.twink(self.b,4)
                return True
            elif k == 'b':
                self.c.undraw()
                self.c.setTextColor('green')
                self.c.draw(self.window)
                return False

        if name == 'asha':
            self.b = Text(Point(self.X, self.Y - 24), "A monster emerges, she appears friendly but looks can be deceiving...")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Asha: Hi! Could you help get my cat from the tree?")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            if met > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Asha: You seem familiar")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            if die > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Asha: And why do you look at me like that?")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
                self.b = Text(Point(self.X, self.Y - 24), "Asha: Is there a ghost behind me?")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Never met a cat lady before...")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.a = Text(Point(self.X, self.Y - 72), "Do you wanna help mher?")
            self.b = Text(Point(self.X, self.Y - 24 ), "OK")
            self.c = Text(Point(self.X, self.Y + 50 ), "Kill her")
            self.d = Text(Point(self.X, self.Y + 72 ), self.word)
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor('red')
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.twink(self.b,4)
                return True
            elif k == 'b':
                self.c.undraw()
                self.c.setTextColor('green')
                self.c.draw(self.window)
                return False
        if name == 'alice':
            self.b = Text(Point(self.X, self.Y - 24), "You run into a monster, she seems harmless enough.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Alice: Hi there! Want a free cookie?")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            if met > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Alice: Have we met before?")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            if die > 0:
                self.b = Text(Point(self.X, self.Y - 24), "Alice: You are pale. What's wrong?")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
                self.b = Text(Point(self.X, self.Y - 24), "Alice: Did you kill people and they revive? Just kidding.")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                a = self.window.getKey()
                self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Lil sus but smells yummy.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.a = Text(Point(self.X, self.Y - 72), "Do you wanna help her?")
            self.b = Text(Point(self.X, self.Y - 24 ), "OK")
            self.c = Text(Point(self.X, self.Y + 50 ), "Kill her")
            self.d = Text(Point(self.X, self.Y + 72 ), self.word)
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor('red')
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.twink(self.b,4)
                return True
            elif k == 'b':
                self.c.undraw()
                self.c.setTextColor('green')
                self.c.draw(self.window)
                return False
        if name == 'note':
            self.b = Text(Point(self.X, self.Y - 24), "There is no one but a note.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            time.sleep(2)
            self.c = Text(Point(self.X, self.Y + 24), "You pick it up.")
            self.c.setSize(25)
            self.c.setTextColor(self.color)
            self.c.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.c.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "'I give you a chance.'")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            time.sleep(2)
            self.c = Text(Point(self.X, self.Y + 24), "That's what it says")
            self.c.setSize(25)
            self.c.setTextColor(self.color)
            self.c.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.c.undraw()
            return True
        if name == 'badending':
            self.b = Text(Point(self.X, self.Y - 24), "Hi! ")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.a = Text(Point(self.X, self.Y - 72), " Do you wanna help me?")
            self.b = Text(Point(self.X, self.Y - 24 ), "OK")
            self.c = Text(Point(self.X, self.Y + 50 ), "Kill")
            self.d = Text(Point(self.X, self.Y + 72 ), self.word)
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor('red')
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.twink(self.b,4)
                return True
            elif k == 'b':
                self.c.undraw()
                self.c.setTextColor('green')
                self.c.draw(self.window)
                return False
        if name == 'reunion':
            self.b = Text(Point(self.X, self.Y - 24), "Alice: Hello! It's us!")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.c = Text(Point(self.X, self.Y + 50 ), "Asha: Yes! We think since you helped us, we should give you something in return!")
            self.c.setSize(25)
            self.c.setTextColor(self.color)
            self.c.draw(self.window)
            a = self.window.getKey()
            self.c.undraw()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Eason: Yesssss, so we want to introducsss you to many friendsssss.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.c = Text(Point(self.X, self.Y + 50 ), "Alice: Or! We can give you lots of treasures we have!")
            self.c.setSize(25)
            self.c.setTextColor(self.color)
            self.c.draw(self.window)
            a = self.window.getKey()
            self.c.undraw()
            self.b.undraw()
            self.a = Text(Point(self.X, self.Y - 72), "Asha: It depends on your choice.")
            self.b = Text(Point(self.X, self.Y - 24 ), "Friends(maximize Peo)")
            self.c = Text(Point(self.X, self.Y + 50 ), "Treasures(maximize Eco)")
            self.d = Text(Point(self.X, self.Y + 72 ), self.word)
            self.a.setSize(25)
            self.b.setSize(25)
            self.c.setSize(25)
            self.a.setTextColor(self.color)
            self.b.setTextColor(self.color)
            self.c.setTextColor(self.color)
            self.a.draw(self.window)
            self.b.draw(self.window)
            self.c.draw(self.window)
            self.d.draw(self.window)
            while True:
                k = self.window.checkKey()
                if k == 'a' or k == 'b':
                    break
            if k == 'a':
                self.twink(self.b,4)
                self.erase()
                self.a = Text(Point(self.X, self.Y - 72), self.word)
                self.b = Text(Point(self.X, self.Y - 24), "The civilization of monsters is marvelous!")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                time.sleep(1)
                self.c = Text(Point(self.X, self.Y + 50 ), "You had a good time.")
                self.c.setSize(25)
                self.c.setTextColor(self.color)
                self.c.draw(self.window)
                self.d = Text(Point(self.X, self.Y + 72 ), self.word)
                a = self.window.getKey()
                return 'peo'
            elif k == 'b':
                self.twink(self.c,4)
                self.erase()
                self.b = Text(Point(self.X, self.Y - 24), "They gave you various treasures maps")
                self.b.setSize(25)
                self.b.setTextColor(self.color)
                self.b.draw(self.window)
                time.sleep(1)
                self.c = Text(Point(self.X, self.Y + 50 ), "Now you are extraodinarily rich.")
                self.c.setSize(25)
                self.c.setTextColor(self.color)
                self.c.draw(self.window)
                a = self.window.getKey()
                return 'eco'
        if name == 'empty':
            self.b = Text(Point(self.X, self.Y - 24), "No one is here.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            return True
    def introreact(self,name):
        if name == 'alice':
            self.b = Text(Point(self.X, self.Y - 24), "You eat the cookie, it has a slight minty flavor.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Alice: Thanks you! Hope it was tasty!")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Yum!")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
        elif name == 'asha':
            self.b = Text(Point(self.X, self.Y - 24), "You scale the tree and bring the cat down safely.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Asha: Thank you!")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Phew, yea no problem.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
        elif name == 'eason':
            self.b = Text(Point(self.X, self.Y - 24), "Eason fixes the buttons on his shirt.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "Eason: Thanksss.")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
            self.b = Text(Point(self.X, self.Y - 24), "No problem ... brosski")
            self.b.setSize(25)
            self.b.setTextColor(self.color)
            self.b.draw(self.window)
            a = self.window.getKey()
            self.b.undraw()
