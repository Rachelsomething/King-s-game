from graphics import *
from Setting import *
from questions import *
from play import *
from data import *
from art import *

PATH_TO_IMAGES_FOLDER = "/Users/labuser/Desktop/Finalproject"


data = Data(PATH_TO_IMAGES_FOLDER)
days = data.returndays()
a = []
f = open(f"{PATH_TO_IMAGES_FOLDER}/notes/name.txt",'r')
for line in f:
    a.append(line)
f.close()
if a == []:
    name = input("What's your name?\n>>>")
    file1 = open(f"{PATH_TO_IMAGES_FOLDER}/notes/name.txt", "a")
    file1.write(name)
    file1.close()
else:
    name = a[0]
win = GraphWin("bigWindow", 1000, 600,)
if '#p' == days[-1][-2:]:
    play = Play(win,'politician',name,PATH_TO_IMAGES_FOLDER)
elif '#a' == days[-1][-2:]:
    play = Play(win,'aristocrat',name,PATH_TO_IMAGES_FOLDER)
else:
    play = Play(win,'villiager',name,PATH_TO_IMAGES_FOLDER)
if data.returnluck()['BadEndingTriggered'] == 1:
    if data.returnluck()['Badmeet'] == 1:
        textw1 = "START"
        center1 = Point(500, 300)
        text1 = Text(center1, textw1)
        text1.setSize(33)
        text1.setFace("helvetica")
        text1.draw(win)
        textw2 = f"{name}, please click 'Start' to begin"
        center2 = Point(500, 350)
        text2 = Text(center2, textw2)
        text2.setTextColor("gray")
        text2.setSize(30)
        text2.setFace("times roman")
        text2.draw(win)
        a = win.getMouse()
        time.sleep(0.3)
        textw3 = "N"
        center3 = Point(485, 270)
        text3 = Text(center3, textw3)
        text3.setSize(35)
        text3.setTextColor("red")
        text3.draw(win)
        time.sleep(0.8)
        textw4 = "O"
        center4 = Point(515, 270)
        text4 = Text(center4, textw4)
        text4.setSize(35)
        text4.setTextColor("red")
        text4.draw(win)
        time.sleep(2)
        text1.undraw()
        text2.undraw()
    play.fight()
else:
    textw1 = "START"
    center1 = Point(500, 300)
    text1 = Text(center1, textw1)
    text1.setSize(33)
    text1.setFace("helvetica")
    text1.draw(win)
    textw2 = f"{name}, please click 'Start' to begin"
    center2 = Point(500, 350)
    text2 = Text(center2, textw2)
    text2.setTextColor("gray")
    text2.setSize(33)
    text2.setFace("times roman")
    text2.draw(win)
    a = win.getMouse()
    text1.undraw()
    text2.undraw()
    time.sleep(0.2)
    art = Art(win,PATH_TO_IMAGES_FOLDER)
    art.graph('startInst')
    time.sleep(0.8)
    if len(days) == 1:
        art.graph('startIn')
    elif '#p' in days[-1][-2:]:
        art.graph('startInP')
    elif '#a' in days[-1][-2:]:
        art.graph('startInA')
    else:
        art.graph('startInV')
    a = Text(Point(500,300), "Season 1")
    a.setSize(30)
    a.draw(win)
    b = win.getKey()
    a.undraw()
    play.eachday(1)
    play.check()
    a = Text(Point(500,300), "Season 2")
    a.setSize(30)
    a.draw(win)
    b = win.getKey()
    a.undraw()
    play.eachday(2)
    play.check()
    a = Text(Point(500,300), "Season 3")
    a.setSize(30)
    a.draw(win)
    b = win.getKey()
    a.undraw()
    play.eachday(3)
    play.check()
    a = Text(Point(500,300), "Season 4")
    a.setSize(30)
    a.draw(win)
    b = win.getKey()
    a.undraw()
    play.eachday(4)
    play.check()
    play.checkEnding()
    play.fight()
    win.close()

"""black = Image(Point(500,300), "/Users/labuser/Desktop/Finalproject/black.gif")
black.draw(win)
battle = Image(Point(500,409), "/Users/labuser/Desktop/Finalproject/battle.gif")
battle.draw(win)"""
"""image22=Image(Point(650,150), "/Users/labuser/Desktop/Finalproject/town.gif")
image = Image(Point(870,150), "/Users/labuser/Desktop/Finalproject/alice.gif")
image3 = Image(Point(660,150), "/Users/labuser/Desktop/Finalproject/eason.gif")
dialogueBar = Rectangle(Point(10,289),Point(990,530))
profileframe = Rectangle(Point(10,10),Point(300,289))
profileframe.setFill('lightyellow')
profileframe.setOutline("lightyellow")
dialogueBar.setOutline("black")
profileframe.draw(win)
image22.draw(win)
image.draw(win)
image3.draw(win)
dialogueBar.draw(win)

image2 = Image(Point(150,162), "/Users/labuser/Desktop/Finalproject/aristocrat.gif")
image2.draw(win)"""

"""a = Circle(Point(50,50), 20)
a.setFill("blue")
a.draw(win)
setting = Bars(win,Point(10,540),Point(990,590),10,50,100)
setting.draw()
a = int(input("please enter a number for eco:"))
setting.changeEco(a)
b = int(input("please enter a number for peo:"))
setting.changePeo(b)
c = int(input("please enter a number for LUCK:"))
setting.changeLUCK(c)
center = Point(250,150)
text = "A\nB"
text = Text(center,text)
text.draw(win)
question = Question(win,Point(500,409),"black")
question.questionep('e')

question.questionf('p')"""
