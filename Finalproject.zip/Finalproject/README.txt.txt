Name： The Game of Kings
Rachel(Yang) Tan & Leo Xiao

“”” This program is a game for you to start a revolution in a kingdom. Based on the different paths you choose, you will reach different endings.”””

Before playing：
1. In the file 'Game_of_kings.py' , please replace ：

PATH_TO_IMAGES_FOLDER = "/path/to/your/folder"

into the path of this folder'Finalproject',

2. Duplicate this folder，keep it safe，you will know why after you reach the ‘Bad Ending’

3. Use Terminal to run the file 'Game_of_kings.py'
=======================================================
Please don not let one of your values(except LUCK) become 0, or game over and you have to restart.

I highly recommend the players play this game multiple times. Every time you will find something special. I created a file to contain the information and changed it during the game. Thus, the game will be different every time you open it. 

Attention! You can never reach the ‘True ending’ in the first round, which is your main goal. Besides, the ‘Bad ending’ is also enticing! Try to reach it on your own!

Current possible ending:
First Round: “Economy Ending”; “Popularity Ending”; “Neutral Ending”
Other(multiple) Rounds: “Economy Ending”; “Popularity Ending”; “Neutral Ending”; “True Ending”; “Bad Ending”; “Almost got it Ending”

Known bugs: Please make sure your computer is not overloaded, or some functions in the program will run very slowly.

PS： In the case that you want to try the game first, I put the conditions to reach each ending and other funny features VERY BELOW
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
⇓⇓
“Economy Ending”: Eco > 70; Peo <= 70; LUCK != 100 
 “Popularity Ending”: Eco <= 70; Peo > 70; LUCK != 100
“Neutral Ending”: Eco <= 70; Peo <= 70; LUCK! = 100
“True Ending”: Eco = 100; Peo = 100; LUCK = 0
“Bad Ending”: Eco = 100; Peo = 100; LUCK = 100
“Almost got it Ending”: Eco = 100; Peo = 100; LUCK != 0
 
For the characters you have met, they will react like they have seen you when you encounter them again in the next round. And please TRY NOT TO  kill them if you want to reach the ‘True ending’ because ‘LUCK’ does not stand for luck.

After Bad Ending, there will be a battle scene for you to fight. The way the boss attack you is by asking the questions that appear in the game and you need to answer correctly in a limited amount of time. I RECOMMEND you die more times to see how the boss reacts(I put lots of effort into that!!!)

