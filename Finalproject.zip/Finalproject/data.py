

class Data:
    def __init__(self,PATH_TO_IMAGES_FOLDER):
        self.PATH_TO_IMAGES_FOLDER = PATH_TO_IMAGES_FOLDER
        self.luck = self.constructLuck()
        self.days = self.constructDays()

    def constructLuck(self):
        luck = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/LUCK.txt", "r")
        luckd = {}
        a = []
        for line in luck:
            line = line[:-1]
            a.append(line)
        for i in range(len(a)//2):
            luckd[a[i*2]] = eval(a[i*2+1])
        luck.close()
        return luckd

    def constructDays(self):
        days = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/Restart.txt",'r')
        a = []
        for line in days:
            a.append(line)
        return a
        days.close()

    def modifyluck(self,key,value):
        v = self.luck[key]
        self.luck[key] = v + value
        f1 = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/LUCK.txt", 'r')
        input_data = f1.read()
        f1.close()
        input_data = input_data.replace(f'{key}\n{v}', f'{key}\n{v + value}')
        f2 = open(f"{self.PATH_TO_IMAGES_FOLDER}/notes/LUCK.txt", 'w')
        f2.write(input_data)
        f2.close()

    def returnluck(self):
        return self.luck

    def returndays(self):
        return self.days
