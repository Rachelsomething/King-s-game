from graphics import *
from random import randint

class Bars:
    """ the values' bara """
    def __init__(self, window, leftPoint, rightPoint,a,b,c,color):
        self.window = window
        self.color = color
        self.X1 = leftPoint.getX()
        self.X2 = rightPoint.getX()
        self.Y1 = leftPoint.getY()
        self.Y2 = rightPoint.getY()
        self.width = self.X2 - self.X1
        self.width2 = (self.X2 - self.X1)*0.80
        self.height = self.Y2 - self.Y1
        self.a = a
        self.b = b
        self.c = c
        self.eco = Rectangle(Point((self.X1 + self.width*0.20), self.Y1 ), Point((self.X2 - ((100-self.a)/100)*self.width2), (self.Y2 - self.height*(8/11))))
        self.peo = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(4/11))), Point((self.X2 - ((100-self.b)/100)*self.width2), (self.Y2 - self.height*(4/11))))
        self.LUCK = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(8/11))), Point((self.X2 - ((100-self.c)/100)*self.width2), self.Y2))
        self.eco.setFill("blue")
        self.eco.setOutline("blue")
        self.peo.setFill("green")
        self.peo.setOutline("green")
        self.LUCK.setFill("yellow")
        self.LUCK.setOutline("yellow")
        ecoCenter = Point((self.X1 + self.width*0.075), (self.Y1+self.height*(1.5/11)))
        textEco = f"econ{self.a}"
        self.ecoT = Text(ecoCenter, textEco)
        peoCenter = Point((self.X1 + self.width*0.075),(self.Y1+self.height*(5.5/11)))
        textPeo = f"peop{self.b}"
        self.peoT = Text(peoCenter, textPeo)
        luckCenter = Point((self.X1 + self.width*0.075),(self.Y1+self.height*(9.5/11)))
        self.textLUCK = f"LUCK{self.c}"
        self.LUCKT = Text(luckCenter, self.textLUCK)

    def draw(self):
        self.eco.draw(self.window)
        self.peo.draw(self.window)
        self.LUCK.draw(self.window)
        self.ecoT.setFace('courier')
        self.peoT.setFace('courier')
        self.LUCKT.setFace('courier')
        self.ecoT.setTextColor(self.color)
        self.peoT.setTextColor(self.color)
        self.LUCKT.setTextColor(self.color)
        self.ecoT.draw(self.window)
        self.peoT.draw(self.window)
        self.LUCKT.draw(self.window)

    def undraw(self):
        self.eco.undraw()
        self.peo.undraw()
        self.LUCK.undraw()
        self.ecoT.undraw()
        self.peoT.undraw()
        self.LUCKT.undraw()

    def move(self,a,b):
        self.eco.move(a,b)
        self.peo.undraw(a,b)
        self.LUCK.undraw(a,b)
        self.ecoT.undraw(a,b)
        self.peoT.undraw(a,b)
        self.LUCKT.undraw(a,b)

    def changeEco(self,a):
        self.eco.undraw()
        self.ecoT.undraw()
        self.a += a
        if self.a >=  100:
            self.a = 100
            self.eco = Rectangle(Point((self.X1 + self.width*0.20), self.Y1 ), Point(self.X2 , (self.Y2 - self.height*(8/11))))
        elif self.a <= 0:
            self.a = 0
            self.eco = Rectangle(Point((self.X1 + self.width*0.20), self.Y1 ), Point(self.X1 + self.width*0.20, (self.Y2 - self.height*(8/11))))
        else:
            self.eco = Rectangle(Point((self.X1 + self.width*0.20), self.Y1 ), Point((self.X2 - ((100-self.a)/100)*self.width2), (self.Y2 - self.height*(8/11))))
        self.eco.setFill("blue")
        self.eco.setOutline("blue")
        ecoCenter = Point((self.X1 + self.width*0.075), (self.Y1+self.height*(1.5/11)))
        textEco = f"econ{self.a}"
        self.ecoT = Text(ecoCenter, textEco)
        self.ecoT.setFace('courier')
        self.ecoT.setTextColor(self.color)
        t = 0
        while t != 3:
            t+=1
            self.ecoT.draw(self.window)
            self.eco.draw(self.window)
            time.sleep(0.1)
            self.eco.undraw()
            self.ecoT.undraw()
            time.sleep(0.1)
        self.ecoT.draw(self.window)
        self.eco.draw(self.window)

    def changePeo(self,b):
        self.peo.undraw()
        self.peoT.undraw()
        self.b += b
        if self.b >= 100:
            self.b = 100
            self.peo = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(4/11))), Point(self.X2 , (self.Y2 - self.height*(4/11))))
        elif self.b <= 0:
            self.b = 0
            self.peo = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(4/11))), Point(self.X1 + self.width*0.20 , (self.Y2 - self.height*(4/11))))
        else:
            self.peo = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(4/11))), Point((self.X2 - ((100-self.b)/100)*self.width2), (self.Y2 - self.height*(4/11))))
        self.peo.setFill("green")
        self.peo.setOutline("green")
        peoCenter = Point((self.X1 + self.width*0.075),(self.Y1+self.height*(5.5/11)))
        textPeo = f"peop{self.b}"
        self.peoT = Text(peoCenter, textPeo)
        self.peoT.setFace('courier')
        self.peoT.setTextColor(self.color)
        t = 0
        while t != 3:
            t+=1
            self.peoT.draw(self.window)
            self.peo.draw(self.window)
            time.sleep(0.1)
            self.peo.undraw()
            self.peoT.undraw()
            time.sleep(0.1)
        self.peoT.draw(self.window)
        self.peo.draw(self.window)

    def changeLUCK(self,c):
        self.LUCK.undraw()
        self.LUCKT.undraw()
        self.c += c
        if self.c >= 100:
            self.c = 100
            self.LUCK = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(8/11))), Point(self.X2 , self.Y2))
        elif self.c <= 0:
            self.c = 0
            self.LUCK = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(8/11))), Point(self.X1 + self.width*0.20 , self.Y2))
        else:
            self.LUCK = Rectangle(Point((self.X1 + self.width*0.20), (self.Y1+self.height*(8/11))), Point((self.X2 - ((100-self.c)/100)*self.width2), self.Y2))
        self.LUCK.setFill("yellow")
        self.LUCK.setOutline("yellow")
        luckCenter = Point((self.X1 + self.width*0.075),(self.Y1+self.height*(9.5/11)))
        self.textLUCK = f"LUCK{self.c}"
        self.LUCKT = Text(luckCenter, self.textLUCK)
        self.LUCKT.setFace('courier')
        self.LUCKT.setTextColor(self.color)
        t = 0
        while t != 3:
            t+=1
            self.LUCKT.draw(self.window)
            self.LUCK.draw(self.window)
            time.sleep(0.1)
            self.LUCK.undraw()
            self.LUCKT.undraw()
            time.sleep(0.1)
        self.LUCKT.draw(self.window)
        self.LUCK.draw(self.window)


    def get(self, status):
        if status == 'eco':
            return self.a
        elif status == 'peo':
            return self.b
        else:
            return self.c
